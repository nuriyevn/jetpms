<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>thx page</title>
</head>
<body>
    <h1>Thx for register</h1>
</body>
</html>