alert("Hello, Javascript!");
